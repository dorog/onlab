A teljes projekt letölthető az alábbi linken:

https://github.com/dorog/onlab