﻿
public class ActualMapData {

    static public int mapNumber = 17;
    static public int createdMapIndex = 0;
    static public int Scarab3PartCmd;
    static public int Scarab2PartCmd;
    static public bool HaveItem = false;
    static public bool HawNewItem = false;

    static public MapResultData solvedMap = new MapResultData();
}
