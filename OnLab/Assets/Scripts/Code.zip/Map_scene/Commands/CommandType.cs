﻿
public enum CommandType {
    GoForward, TurnRight, TurnLeft, Activate, FV1, FV2, Null
}
