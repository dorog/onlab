﻿using UnityEngine;

public enum CanGoForward{
    OneDiff, CantGo, Go
}
